## Tabla de contenido
1. [Informacion general](general-info)
2. [Tecnologías](technologies)
3. [Ejecución](installation)
### General Info
***


## Tecnologías
***
Esta es la lista de tecnologias utilizadas:
* [Serenity-Cumcumber](https://mvnrepository.com/artifact/net.serenity-bdd/serenity-cucumber/)
* [Serenity-Rest](https://mvnrepository.com/artifact/net.serenity-bdd/serenity-cucumber/)
* [Serenity-WebDriver](https://mvnrepository.com/artifact/net.serenity-bdd/serenity-screenplay-webdriver/)
* [Serenity-Core](https://mvnrepository.com/artifact/net.serenity-bdd/serenity-core/)
* [Serenity-ScreenPlay](https://mvnrepository.com/artifact/net.serenity-bdd/serenity-screenplay/)
## Ejecución
***
Se debe seguir los siguientes pasos 
```

* Se puede ejecutar todo el proyecto desde la terminal de gradle con el
  comando $gradle clean test


```
